var photoButton = document.getElementById('snapPicture');
photoButton.addEventListener('click', picCapture, false);


navigator.getUserMedia ||
    (navigator.getUserMedia = navigator.mozGetUserMedia || navigator.websiteGetUserMedia || navigator.msGetUserMedia);

if (navigator.getUserMedia)
    {
        navigator.getUserMedia((video:true,audio:false), onSucess, onError)
    }
        else{
            alert('Your Browser is not supported');
        }
   
function onSucess(stream){
    videoContainer = document.getElementById('webcam');
    var vidStream;
    
    if (window.webkitUTL)
        {
            vidStream=window.webkitURL.createObjectURL(stream);
        }
    else{
        vidStream=stream;
    }
    
    vidContainer.autoplay = true;
    videoContainer.src=vidStream;
}

function onError(){
    alert('Error!');
}

function picCapture()
{
    var picture=document.getElementById('capture'), 
        context=picture.getContext('2d');
    
    picture.width="600";
    picture.height="400";
    
    context.drawImage(videoContainer, 0,0,picture.width, picture.height);
    var dataURL = picture.toDataURL();
    document.getElementById('canvasimg').src = dataURl;
}




